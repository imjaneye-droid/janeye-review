const KEY = "janeye_reviews_v1";
let reviews = JSON.parse(localStorage.getItem(KEY) || "[]");
let selectedRating = 5;

const $ = (id) => document.getElementById(id);

function save() {
  localStorage.setItem(KEY, JSON.stringify(reviews));
}

function formatDate(iso) {
  return new Intl.DateTimeFormat("th-TH", {
    year:"numeric", month:"2-digit", day:"2-digit",
    hour:"2-digit", minute:"2-digit"
  }).format(new Date(iso));
}

function render() {
  const list = $("reviews");
  list.innerHTML = "";

  $("reviewCount").textContent = reviews.length;
  const avg = reviews.length
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : "0.0";
  $("averageRating").textContent = avg;

  $("empty").style.display = reviews.length ? "none" : "block";

  [...reviews].reverse().forEach((r) => {
    const article = document.createElement("article");
    article.className = "review";
    const initial = (r.name || "?").trim().charAt(0).toUpperCase();
    const stars = "★".repeat(r.rating) + "☆".repeat(5-r.rating);
    article.innerHTML = `
      <div class="review-top">
        <div class="avatar">${escapeHtml(initial)}</div>
        <div>
          <div class="review-name">${escapeHtml(r.name)}</div>
          <div class="date">${formatDate(r.createdAt)}</div>
        </div>
      </div>
      <div class="stars">${stars}</div>
      <p>${escapeHtml(r.comment).replace(/\n/g,"<br>")}</p>
      ${r.photo ? `<img class="review-photo" src="${r.photo}" alt="รูปประกอบรีวิว">` : ""}
    `;
    list.appendChild(article);
  });

  renderAdmin();
}

function renderAdmin() {
  const box = $("adminReviews");
  box.innerHTML = "";
  if (!reviews.length) {
    box.innerHTML = '<p class="note">ยังไม่มีรีวิว</p>';
    return;
  }
  reviews.slice().reverse().forEach((r) => {
    const row = document.createElement("div");
    row.className = "admin-row";
    row.innerHTML = `
      <div><b>${escapeHtml(r.name)}</b><br><small>${r.rating} ★ · ${escapeHtml(r.comment.slice(0,45))}</small></div>
      <button class="danger delete-one" data-id="${r.id}" style="width:auto;margin:0;padding:9px 12px">ลบ</button>
    `;
    box.appendChild(row);
  });
  box.querySelectorAll(".delete-one").forEach(btn => {
    btn.addEventListener("click", () => {
      reviews = reviews.filter(r => r.id !== btn.dataset.id);
      save(); render();
    });
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

function openModal(id){ $(id).classList.remove("hidden"); }
function closeModal(id){ $(id).classList.add("hidden"); }

$("writeBtn").addEventListener("click", () => openModal("reviewModal"));
$("adminBtn").addEventListener("click", () => openModal("adminModal"));

document.querySelectorAll("[data-close]").forEach(b =>
  b.addEventListener("click", () => closeModal(b.dataset.close))
);

document.querySelectorAll("#starPicker button").forEach(btn => {
  btn.addEventListener("click", () => {
    selectedRating = Number(btn.dataset.star);
    $("rating").value = selectedRating;
    document.querySelectorAll("#starPicker button").forEach(b =>
      b.classList.toggle("active", Number(b.dataset.star) <= selectedRating)
    );
  });
});
document.querySelectorAll("#starPicker button").forEach(b => b.classList.add("active"));

$("reviewForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const file = $("photo").files[0];

  const addReview = (photo) => {
    reviews.push({
      id: crypto.randomUUID(),
      name: $("name").value.trim(),
      rating: selectedRating,
      comment: $("comment").value.trim(),
      photo: photo || "",
      createdAt: new Date().toISOString()
    });
    save();
    e.target.reset();
    selectedRating = 5;
    document.querySelectorAll("#starPicker button").forEach(b => b.classList.add("active"));
    closeModal("reviewModal");
    render();
  };

  if (file) {
    const reader = new FileReader();
    reader.onload = () => addReview(reader.result);
    reader.readAsDataURL(file);
  } else {
    addReview("");
  }
});

$("clearAll").addEventListener("click", () => {
  if (confirm("ลบรีวิวทั้งหมดที่บันทึกไว้ในเครื่องนี้ใช่ไหม?")) {
    reviews = [];
    save();
    render();
  }
});

render();