janeye review website

Upload these 5 files to the root of the GitHub repository:
index.html
styles.css
app.js
profile.jpeg
cover.jpeg

This first version is a visual/functional prototype. Reviews are stored in the browser only. The next step is connecting a real online database (Supabase) so reviews are shared between customers and the shop can manage them securely.
